<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ejemplo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener datos del formulario
$dept_no = $_POST['dept_no'];
$dnombre = $_POST['dnombre'];
$loc = $_POST['loc'];

// Insertar datos en la tabla departamentos
$sql = "INSERT INTO departamentos (dept_no, dnombre, loc) VALUES ('$dept_no', '$dnombre', '$loc')";

if ($conn->query($sql) === TRUE) {
    echo "Departamento insertado correctamente.";
} else {
    echo "Error al insertar departamento: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>