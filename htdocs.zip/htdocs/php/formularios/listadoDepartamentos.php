<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ejemplo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener el listado de departamentos
$sql = "SELECT * FROM departamentos";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Mostrar el encabezado de la tabla
    echo "<table border='1'>
            <tr>
                <th>Número de Departamento</th>
                <th>Nombre del Departamento</th>
                <th>Ubicación</th>
            </tr>";

    // Mostrar filas de datos
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["dept_no"] . "</td>
                <td>" . $row["dnombre"] . "</td>
                <td>" . $row["loc"] . "</td>
            </tr>";
    }

    echo "</table>";
} else {
    echo "No se encontraron departamentos.";
}

// Cerrar la conexión
$conn->close();
?>
