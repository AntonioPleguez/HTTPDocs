<?php
include './conexionBd.php';
include './Vistas.php';

$vista = new Vistas();
$db = new BaseDatos();
$db->conecta();
?>
<!DOCTYPE html>
<!--//Autor: Antonio Pleguezuelo -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="insertarClientes.php" method = "POST" id = "darDeAltaClientes">
        <input type="text" id = "codigoCli" name = "codigoCli" placeholder = "Codigo del cliente"><br><br>
        <input type="text" id = "razon" name = "razon" placeholder = "Razon del cliente"><br><br>
        <input type="text" id = "direccion" name = "direccion" placeholder = "Direccion del cliente"><br><br>
        <input type="tel" id = "telefono" name = "telefono" placeholder = "Telefono del cliente"><br><br>
        <input type="submit" id = "enviar" name = "enviar"><br><br>
    </form>
<section><button>Ver clientes<?php $vi = $vista->verClientes($db-> consulta("Select * from clientes"))?>

</button></section></body>
</html>