<?php

class Conexion
{
    private $server;
    private $usuario;
    private $pass;
    private $baseDeDatos;
    private $conex;

    public function __construct()
    {
        $this->server = "localhost";
        $this->usuario = "root";
        $this->pass = "";
        $this->baseDeDatos = "i1i26";
        $this->conex = new mysqli();
    }

    public function conectarBd( ){
        $this->conex->connect($this->server, $this->usuario, $this->pass, $this->baseDeDatos);
    }
    public function consultar($sql){
        $this->conex->query($sql);
    }
    
}
