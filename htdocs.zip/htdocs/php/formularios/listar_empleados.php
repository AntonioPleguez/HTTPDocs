<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ejemplo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener datos del formulario
$dept_no = $_POST['dept_no'];

// Consulta para obtener los empleados del departamento especificado
$sql = "SELECT * FROM empleados WHERE dept_no = $dept_no";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Mostrar los empleados en forma de lista
    echo "<h2>Empleados del Departamento</h2>";
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>" . $row["nombre_emp"] . " - Salario: $" . $row["salario"] . "</li>";
    }
    echo "</ul>";
} else {
    echo "No se encontraron empleados para el departamento seleccionado.";
}

// Cerrar la conexión
$conn->close();
?>
