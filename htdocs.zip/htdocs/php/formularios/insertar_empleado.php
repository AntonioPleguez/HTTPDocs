<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ejemplo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener datos del formulario
$emp_no = $_POST['emp_no'];
$dept_no = $_POST['dept_no'];
$nombre_emp = $_POST['nombre_emp'];
$salario = $_POST['salario'];

// Insertar datos en la tabla empleados
$sql = "INSERT INTO empleados (emp_no, dept_no, nombre_emp, salario) VALUES ('$emp_no', '$dept_no', '$nombre_emp', '$salario')";

if ($conn->query($sql) === TRUE) {
    echo "Empleado insertado correctamente.";
} else {
    echo "Error al insertar empleado: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
