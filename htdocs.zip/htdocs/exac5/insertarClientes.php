<?php
include './conexionBd.php';
//Autor: Antonio Pleguezuelo
$bada = new BaseDatos();
$bada-> conecta();

if (mysqli_connect_errno()){
    echo "Fallo de conexion a la base de datos";
    exit();    
};
$codigo = $_POST["codigoCli"];
$razon = $_POST["razon"];
$direccion = $_POST["direccion"];
$telefono = $_POST["telefono"];

$query2 = "SELECT * FROM paises WHERE NPAIS LIKE '$direccion'";
$query = "INSERT INTO CLIENTES (CODIGOCLI, RAZON, DIRECCION, TELEFONO) VALUES ('$codigo',
'$razon', '$direccion', '$telefono')";

$rsP = $bada->consulta($query2);

if($codigo !== '' && $razon !== '' && $direccion !== '' && $telefono !== ''){
$rsC = $bada->consulta($query);};


if($rsC == false)
    echo "La consulta a fallado";
else echo "Registro guardado";


?>