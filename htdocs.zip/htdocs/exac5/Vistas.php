<?php
//Autor Antonio Pleguezuelo
class Vistas
{

  public function verClientes($rsC)
  {
    $cont = 1;

    while ($row = $rsC->fetch_array())
    {
    echo "<table><tr><td>" . $row["CODIGOCLI"] . "</td>";
    echo "<td>" . $row["RAZON"] . "</td>";
    echo "<td>" . $row["DIRECCION"] . "</td>";
    echo "<td>" . $row["TELEFONO"] . "</td></tr></table>";



    $cont++;
    };
  }

 /* public function listaPremios($row, $marca)
  {
    echo '<tr>
           <td class="mayusculas">' . $row['nombre'] . '</td>
           <td class="mayusculas">' . $row['depto'] . '</td>
           <td class="mayusculas">' . $row['ausencias'] . '</td>
           <td class="mayusculas">' . $marca['marca'] . '</td>
          </tr>';
  }*/

}
