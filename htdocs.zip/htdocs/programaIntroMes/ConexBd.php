<?php

class ConexBd
{
    private $host;
    private $user;
    private $pass;
    private $bbdd;
    private $conex;

    public function __construct()
    {
      $this->host = "localhost";
      $this->user = "root";
      $this->pass = "";
      $this->bbdd = "i1i20";
      $this->conex = new mysqli();
    }
  
    public function conecta()
    {
      $this->conex->connect($this->host, $this->user, $this->pass, $this->bbdd);
    }
  
    public function consulta($sql)
    {
      return $this->conex->query($sql);
    }
  
    public function inicializaConsulta($rs)
    {
      return mysqli_data_seek($rs, 0);
    }
  
    public function desconecta()
    {
      $this->conex->close();
    }
    



}

?>