<?php
include './Bbdd.php';
include './Vistas.php';

$vista = new Vistas();
$db = new Bbdd();
$db->conecta();
?>
<html>
  <head>
    <meta charset="UTF-8">
    <title>ALTAS clientes</title>
    <link rel="stylesheet" href="estilos.css"/>
  </head>
  <body>
  <h1>clientes</h1>
  <br>
    <form action="index.php" method="POST" id="form">
      
     pais 
      <select id="seleccionPais" name="seleccionPaiss">
        <?php
		$db->AsignarPosicion();
        $vista->seleccionColores($db->consulta("SELECT * FROM paises order by Npais"));
        
		?>
      </select>
	  
      Nombre: 
      <input type="text" name="codigo" id="codigo">
	   <input type="text" name="razon" id="razon">
	    <input type="text" name="direccion" id="direccion">
		 <input type="text" name="telefono" id="telefono">
      
      <input type="submit" id="send" name="send" value="Alta"/>
    </form>
<table>
        <?php
		$rs=$db->consulta("SELECT * FROM clientes ");
		while ($row = $rs->fetch_array())
		{
			$vista->listaParticipantes($row);
      
		}
        
        
		?>
      
</table>

    <?php if($_POST) {  ?>
    
      <?php
      $email = $_POST['razon'];
      $nombre = $_POST['nombre'];
      $seleccionColores = $_POST['seleccionColores'];

      $rm = $db->consulta("SELECT Correo FROM sorteoinfo");

      $check = 0;

      while ($row = $rm->fetch_array())
      {
        if(strtoupper($email)==strtoupper($row[0])){
          echo("El correo que ha introducido ya esta registrado");
          $check=1;
        }
      }


      if ($check==1) {
      } else{
        $ins = $db->consulta("INSERT INTO sorteoinfo VALUES ('$email', '$nombre', '$seleccionColores')");

        $rs = $db->consulta("SELECT * FROM sorteoinfo");

        $contador=0;
        while ($row = $rs->fetch_array())
        {
        $contador++;
        $vista->listaParticipantes($row);
        }

        if ($contador>5) {
          $vista->botonSorteo();
        }
      }
          
      ?>
    </table>
    <script src="javascript.js" type="text/javascript"></script>

    <?php }
     ?>


  </body>
</html>
<?php
$db->desconecta();
?>
