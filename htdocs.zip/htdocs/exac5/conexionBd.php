<?php
//Autor: Antonio Pleguezuelo
class BaseDatos
{

  private $host;
  private $user;
  private $pass;
  private $nombreBd;
  private $conx;

  public function __construct()
  {
    $this->host = "192.168.33.214";
    $this->user = "sanjose";
    $this->pass = "SQL_2710_jsp";
    $this->nombreBd = "i1i20";
    $this->conx = new mysqli();
  }

  //mysqli_set_charset($conx, "utf8");

  public function conecta()
  {
    $this->conx->connect($this->host, $this->user, $this->pass, $this->nombreBd);
  }

  public function consulta($sql)
  {
    return $this->conx->query($sql);
  }

  public function inicializaConsulta($rs)
  {
    return mysqli_data_seek($rs, 0);
  }

  public function desconecta()
  {
    $this->conx->close();
  }

}

?>
