<?php

class Bbdd
{

  private $host;
  private $user;
  private $pass;
  private $bbdd;
  private $conx;

  public function __construct()
  {
    $this->host = "192.168.33.214";
    $this->user = "sanjose";
    $this->pass = "SQL_2710_jsp";
    $this->bbdd = "i1i15";
    $this->conx = new mysqli();
  }

  public function conecta()
  {
    $this->conx->connect($this->host, $this->user, $this->pass, $this->bbdd);
  }

  public function consulta($sql)
  {
    return $this->conx->query($sql);
	
  }

  
 

  public function desconecta()
  {
    $this->conx->close();
  }
  
  public function  AsignarPosicion(){
	  
	  $rs = $this->consulta("SELECT * FROM paises ORDER BY NPAIS");
      $contador=1;
	 
      while ($row = $rs->fetch_array())
      {
		 echo "update paises set posicion=".$contador." where NPAIS='".$row['NPAIS']."'";
         $rup =$this->consulta("update paises set posicion=".$contador." where NPAIS='".$row['NPAIS']."'");
		 $contador++;
      }
	  
	  
  }

}

?>
