<?php
echo '<?xml version="1.0" encoding="UTF-8"?>'
    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <title>Título</title>
</head>

<body>
    <?php
    $i = 1;
    while ($i <= 100) {
        echo "$i <br />";
        $i++;
    }

    echo srand(time());
    $diaSemana = rand(1, 7);
    switch ($diaSemana) {
        case 1:
            $dia = "Lunes";
            break;
        case 2:
            $dia = "Martes";
            break;
        case 3:
            $dia = "Miércoles";
            break;
        case 4:
            $dia = "Jueves";
            break;
        case 5:
            $dia = "Viernes";
            break;
        case 6:
            $dia = "Sábado";
            break;
        case 7:
            $dia = "Domingo";
            break;
        default:
            $dia = "?";
    }
    echo $dia
        ?>
</body>

</html>