<?php

header("Refresh: 0; url=index.php");


$host = "localhost";
$user = "root";
$password = "";
$database = "i1i26";


$c_licor = $_POST['licor'];
$c_marca = $_POST['marca'];


$db = new mysqli($host, $user, $password, $database);

$query = "INSERT INTO datlic (licor,marca) VALUES ('$c_licor','$c_marca')";
$db->query($query);


?>
