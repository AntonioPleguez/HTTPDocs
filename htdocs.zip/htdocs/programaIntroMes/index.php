<?php
include './ConexBd.php';
include './Vistas.php';

$vista = new Vistas;
$bd = new ConexBd;
$bd->conecta();

?>
<html>

<head>
    <meta charset="UTF-8">

    <title>Introduce el mes</title>

</head>

<body>
    <input type="text" placeholder="Mes">
    <select id="seleccionDept" name="seleccionDept">
        <?php
        $vista->seleccionDept($db->consulta("SELECT DISTINCT DEPTO  FROM   datemp")); //
        ?>
    </select>
</body>

</html>
<?php
$db->desconecta();
?>